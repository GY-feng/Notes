class Task:
    def __init__():
        pass

    def get_description():
        pass
    def set_description():
        pass
    

    def get_priority():
        pass

    def set_priority():
        pass

    def get_deadline():
        pass

    def set_deadline():
        pass

    def __str__():
        pass

        
class PriorityQueue:
    def __init__():
        pass

    def add_task():
        pass

    def remove_task():
        pass

    def peek_task(self):
        pass
        
    def get_tasks():
        pass

class Scheduler:
    def __init__():
        pass

    def add_task():
        pass

    def remove_task():
        pass

    def reorder_task():
        pass

    def execute_task():
        pass

    def display_tasks():
        pass



def main():
    pass

if __name__ == '__main__':
    main()
